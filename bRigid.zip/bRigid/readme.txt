bRigid provides classes for an easier handling of jBullet in Processing. bRigid is thought as a kind of Processing port for the bullet physics simulation library written in C++. This library allows the interaction of rigid bodies in 3D. Geometry/ Shapes are build with Processing PShape Class, for convinient display and export(dxf) 

jBullet is a Java port of Bullet (c) 2008 Martin Dvorak http://jbullet.advel.cz/
Bullet Continuous Collision Detection and Physics Library (c) 2003-2013 Erwin Coumans http://www.bulletphysics.com/ 
and many thanks to the jBullet/processing examples of Giulio Piacentino and Richard Brauer 

bRigid written by Daniel Koehler - 2011-2016 www.lab-eds.org - for feedback please contact me at: daniel@lab-eds.org